$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
if (-not (Get-Command node -ErrorAction SilentlyContinue)) { throw 'Install Node.js 20 or newer, then retry.' }
Write-Host 'Open http://127.0.0.1:3100 after the server starts. Keep this window open.'
node .\server.mjs
